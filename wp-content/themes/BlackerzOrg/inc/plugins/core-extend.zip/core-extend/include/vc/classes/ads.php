<?php
class WPBakeryShortCode_Mnky_Ads extends WPBakeryShortCode {
    // public function outputTitle($title) {
        // return '';
    // }
}