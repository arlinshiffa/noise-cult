<?php

class WPBakeryShortCode_Mnky_Service extends WPBakeryShortCode {
}