<?php
class WPBakeryShortCode_Mnky_Posts extends WPBakeryShortCode {
    // public function outputTitle($title) {
        // return '';
    // }
}