<?php
class WPBakeryShortCode_Mnky_Menu_Posts extends WPBakeryShortCode {
    // public function outputTitle($title) {
        // return '';
    // }
}