<?php
class WPBakeryShortCode_Mnky_Heading extends WPBakeryShortCode {

}