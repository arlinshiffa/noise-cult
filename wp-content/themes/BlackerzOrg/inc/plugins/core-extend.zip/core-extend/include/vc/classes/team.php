<?php

class WPBakeryShortCode_Mnky_Team extends WPBakeryShortCode {

}