<?php

class WPBakeryShortCode_Mnky_Counter extends WPBakeryShortCode {

}