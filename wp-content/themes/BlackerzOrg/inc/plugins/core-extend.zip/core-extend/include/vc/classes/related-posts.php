<?php
class WPBakeryShortCode_Mnky_Related_Posts extends WPBakeryShortCode {
    // public function outputTitle($title) {
        // return '';
    // }
}